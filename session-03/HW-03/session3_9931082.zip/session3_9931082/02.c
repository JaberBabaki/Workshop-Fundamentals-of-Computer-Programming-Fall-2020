#include <stdio.h>

int main() {
    char x;
    printf("enter a char:\n");
    scanf("%c",&x);
    printf("%d\n",x);
    return 0;
}
