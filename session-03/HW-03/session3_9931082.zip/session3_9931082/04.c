#include <stdio.h>

int main() {
    printf("%6.2f",0.00);
    printf("%6d\t",12);
    printf("%6d",67831);

    printf("\n");

    printf("%6d\t",779892);
    printf("%6.3f\t",3.0);
    printf("%6.3f\t",33.0);
    return 0;
}
