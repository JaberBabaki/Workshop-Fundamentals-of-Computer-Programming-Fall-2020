#include <stdio.h>

int main() {
    int x ;
    int y ;
    scanf("%d",&x) ;
    scanf("%d",&y) ;
    printf("the result is : %d\n" , (x+y)) ;
    return 0;
    }

