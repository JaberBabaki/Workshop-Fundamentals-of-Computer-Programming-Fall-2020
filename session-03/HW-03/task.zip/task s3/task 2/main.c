#include <stdio.h>

int main() {
    char x ;
    printf("enter a character :\n") ;
    scanf("%c", &x) ;
    printf("%d\n" , x) ;
}
