#include <stdio.h>

int main() {
    printf("line1  line2  line3\n") ;

    printf("%-6.f %-6.3f %-6.f\n" , 0.00 , 12.0 , 67831.0 ) ;

    printf("%-6.f %-6.3f %-6.f\n" , 779892.2422 , 3.0 , 33.0) ;

    return 0;
}