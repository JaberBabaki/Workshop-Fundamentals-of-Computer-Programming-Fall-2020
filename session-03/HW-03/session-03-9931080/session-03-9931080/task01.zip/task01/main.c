#include <stdio.h>

int main() {
    int x,y;
    scanf("%d",&x);
    scanf("%d",&y);
    printf("The result is: %d\n", (x+y));
    return 0;
}
