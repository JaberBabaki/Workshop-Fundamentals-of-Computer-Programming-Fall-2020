#include <stdio.h>

int main() {
    char x;
    printf("Enter a character: \n");
    scanf("%c", &x);
    printf("%d\n", x);
    return 0;
}
