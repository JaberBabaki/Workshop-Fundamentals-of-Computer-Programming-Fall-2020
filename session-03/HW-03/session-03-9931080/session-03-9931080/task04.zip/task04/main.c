#include <stdio.h>

int main() {
    float x=0.00;
    int y=12;
    int z=67831;
    float a=779892.2422;
    int b=3;
    float c=33.0;
    printf("%6.4f\t %6.3f\t %6d\n", x , (float)y , z);
    printf("%6.0f\t %6.3f\t %6.3f\n", a , (float)b , c);
    return 0;
}
