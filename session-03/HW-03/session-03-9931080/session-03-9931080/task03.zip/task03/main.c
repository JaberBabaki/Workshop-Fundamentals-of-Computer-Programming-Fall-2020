#include <stdio.h>

int main() {
    printf("int: %ld \n", sizeof(int));
    printf("float: %ld \n", sizeof(float));
    printf("char: %ld \n", sizeof(char));
    printf("double: %ld \n", sizeof(double));
    return 0;

}