/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    float x1,x2,x3,x4,x5,x6 ;
    scanf("%f%f%f%f%f%f",&x1,&x2,&x3,&x4,&x5,&x6);
    printf("%-6.2f%-6.3f%-6.0f\n%-6.0f%-6.3f%-6.1f",x1,x2,x3,x4,x5,x6);
    return 0;
}
